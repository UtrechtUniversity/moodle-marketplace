CHANGELOG
=========
[v5.2-r2 (2025-07-07)](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v5.2-r2)
---------------------
This release contains fixes for bugs that were found as well as some code debt refactorings:

**Bug fixes**:

- Fix missing reference to first post after creating a new discussion ([#276](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/276))
- Fix typo and wrong DB data read in review functionality ([#277](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/277))

**Refactoring**:

- Fix moodle.org checks and delete some more lines in the locallib ([#273](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/273))

[v5.2-r1 (2025-05-07)](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v5.2-r1)
---------------------
Moodleoverflow had a lot of changes in the last months. Most of them were directly for developers, but they were
improvements for users too like the course overview integration. This year's vision is to reduce the code debt
that build up over the last few years. This is the first release towards that goal.

A short summary:

**New features**:

- Course overview integration ([#257](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/257), [#261](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/261), [#264](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/264))
  - Moodleoverflow now supports the course overview page, showing unread posts and give the user the ability to change readtracking/subscription setting.
- Activity choose improvements ([#260](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/260), [#263](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/263))

**Bug fixes**:

- Fix video embedding in posts ([#255](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/255))
- Fix missing SVG icon ([#270](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/270))

**Refactoring**:

- Major locallib reduction ([#271](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/271))
  - Removed ~1,400 lines from locallib.php by replacing old procedural printing functions with output classes that represent single components
- External functions moved to dedicated classes ([#267](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/267))

Special thanks to [lucaboesch](https://github.com/lucaboesch) and [humanspaces](https://github.com/humanspaces) for contributing to this release!

[v5.1-r2 (2025-12-22)](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v5.1-r2)
---------------------
A new set of updates are waiting for a new release! And there is no better christmas gift than a new
moodleoverflow version. Here's a list of the recent changes:
- Completions with passing grades are now possible ([#253](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/253))
- Discussion title is no more editable in the reply form ([#250](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/250))
- Reply form displays the post it is referring to ([#249](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/249))

[v5.1-r1 (2025-11-27)](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v5.1-r1)
---------------------
Moodleoverflow had a lot of bug fixes as well as code improving changes.
Here a list of the most important changes:
- Fix for errors and false rendering when editing posts ([#233](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/233), [#244](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/244))
- Bugfix in "Mark posts as read"-button ([#232](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/232))
- No more missing activity completion ([#238](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/238))
- Improved behavior for moving discussions ([#239](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/239), [#241](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/241))

[v5.0-r1 (2025-08-01)](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v5.0-r1)
------------------
- Fixes Issues [#216](https://github.com/learnweb/moodle-mod_moodleoverflow/issues/216),
               [#211](https://github.com/learnweb/moodle-mod_moodleoverflow/issues/211),
               [#202](https://github.com/learnweb/moodle-mod_moodleoverflow/issues/202)
- Adaption to Moodle 5.0

[v4.5-r2 (2025-05-19](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.5-r2)
------------------
- fix for [#214](https://github.com/learnweb/moodle-mod_moodleoverflow/pull/214)

[v4.5-r1 (2025-05-06)](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.5-r1)
------------------
* Moodle 4.5 compatible version

[v4.2-r2](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.2-r2)
------------------
Bug Fixes:

* Fix Page Layout https://github.com/learnweb/moodle-mod_moodleoverflow/pull/149 thanks @lucaboesch
* Improve userstats page - have consistent handling for anonymous moodleoverflows https://github.com/learnweb/moodle-mod_moodleoverflow/pull/147 @TamaroWalter
* Fix attachment not found https://github.com/learnweb/moodle-mod_moodleoverflow/pull/146 @TamaroWalter

[v4.2-r1](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.2-r1)
------------------
New Features:

* discussion can be moved to another moodleoverflow forum of the same course https://github.com/learnweb/moodle-mod_moodleoverflow/pull/119
* unread posts email can be send on a daily basis (inherits forumsetting) https://github.com/learnweb/moodle-mod_moodleoverflow/pull/119
* user behaviour in moodleoverflow forums can be seen in a statistics (how many up- and downvotes a user has, his activity and reputation in the course) for one course https://github.com/learnweb/moodle-mod_moodleoverflow/pull/120
* new setting "multiplemarks", which allows to mark multiple post as solved and/or helpful. Setting can be turned on and off at any time for single moodleoverflows. https://github.com/learnweb/moodle-mod_moodleoverflow/pull/128 (description), https://github.com/learnweb/moodle-mod_moodleoverflow/pull/130 (commits)

bug fixes:

* duplicate forum title and description removed https://github.com/learnweb/moodle-mod_moodleoverflow/issues/121
* never ending query in privacy provider fixed

[v4.1-r1](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.1-r1)
------------------
Bug fixes:
* print header only once
* hide anonymous student names to teacher in edit message
* add missing capability strings
* use allowforcesubscribe capability for subscription
* minor style fixes

[v4.0-r4](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.0-r4)
------------------
* Allow admins to enable the moderation feature
*  moderation feature means:
* Either questions (initial post) or questions and comments are reviewed before they are published
* Reviewers are, by default, teachers (capability can be assigned to further roles)
* Authors of rejected posts/questions are notified with an e-mail and an optional reasoning
* Minor security fix so the post can only be changed by the author
* Changes for anonymous feature
* Setting for disallowing of creation of anonymous moodleoverflows is now working
* Admin can choose between changing existing forums to not anonymous or disabling the setting for future moodleoverflows

[v4.0-r3](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.0-r3)
------------------
* Allow admins to enable the moderation feature
* moderation feature means:
* Either questions (initial post) or questions and comments are reviewed before they are published
* Reviewers are, by default, teachers (capability can be assigned to further roles)
* Authors of rejected posts/questions are notified with an e-mail and an optional reasoning
* Minor security fix so the post can only be changed by the author
* Changes for anonymous feature
* Setting for disallowing of creation of anonymous moodleoverflows is now working
* Admin can choose between changing existing forums to not anonymous or disabling the setting for future moodleoverflows

[v4.0-r2](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.0-r2)
------------------
* Bug fix

[v4.0-r1](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v4.0-r1)
------------------
* Compatibility for Moode 4.0
* Overhaul of anonymous Feature
* Style update
* Enable teachers to make reputation and voting optional

[v3.11-r2](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v3.11-r2)
------------------
* Anonymous forum feature and some style and bug fixes

[v3.11-r1](https://github.com/learnweb/moodle-mod_moodleoverflow/releases/tag/v3.11-r1)
------------------
* Minor Bug fixes

v3.10-r1 (2020111200)
------------------
### Fixes

 * MySQL support for queries
 * Do not escape subject titles
 * Added grades table to privacy provider
 * Only allow using grade as activity completion goal if grading is activated

### Other Changes

* Added support for 3.10
